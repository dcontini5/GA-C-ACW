#pragma once

typedef const int MessageType;

struct MessageTypes {

	static MessageType COLLISION = 1;

	
	static MessageType ADDED_COMPONENT = 8;
	
};