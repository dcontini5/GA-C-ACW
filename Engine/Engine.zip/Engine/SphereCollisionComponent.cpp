﻿#include "SphereCollisionComponent.h"
SphereCollisionComponent::SphereCollisionComponent(GameObjectPtr& pParent): CollisionComponent(pParent, ColliderTypes::SPHERE) {}
