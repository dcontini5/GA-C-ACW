﻿#include "SceneManager.h"
SceneManager* SceneManager::mInstance = nullptr;

